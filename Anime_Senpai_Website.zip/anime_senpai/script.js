const anime=[
["Naruto","أكشن • مغامرة","https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600"],
["One Piece","مغامرة • شونين","https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?w=600"],
["Demon Slayer","أكشن • فانتازيا","https://images.unsplash.com/photo-1541560052-77ec1bbc09f7?w=600"],
["Jujutsu Kaisen","أكشن • خارق للطبيعة","https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600"],
["Attack on Titan","أكشن • دراما","https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?w=600"],
["Dragon Ball","قتال • مغامرة","https://images.unsplash.com/photo-1608889825103-eb5ed706fc64?w=600"]
];
const manga=[
["Solo Leveling","مانغا • أكشن","https://images.unsplash.com/photo-1613376023733-0a73315d9b06?w=600"],
["Berserk","مانغا • فانتازيا مظلمة","https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600"],
["Blue Lock","مانغا • رياضة","https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=600"],
["Chainsaw Man","مانغا • أكشن","https://images.unsplash.com/photo-1614583225154-5fcdda07019e?w=600"]
];

function render(items,id){
 const grid=document.getElementById(id);
 grid.innerHTML=items.map((x,i)=>`<article class="card"><img class="poster" src="${x[2]}" alt="${x[0]}"><div class="card-body"><h3>${x[0]}</h3><div class="meta">${x[1]}</div><button class="fav" onclick="favorite(this)">♡ إضافة للمفضلة</button></div></article>`).join("");
}
function favorite(btn){btn.classList.toggle("active");btn.textContent=btn.classList.contains("active")?"♥ في المفضلة":"♡ إضافة للمفضلة"}
render(anime,"animeGrid");render(manga,"mangaGrid");

document.getElementById("search").addEventListener("input",e=>{
 const q=e.target.value.toLowerCase();
 render(anime.filter(x=>x[0].toLowerCase().includes(q)),"animeGrid");
});
document.getElementById("themeBtn").onclick=()=>{
 document.body.classList.toggle("light");
 document.getElementById("themeBtn").textContent=document.body.classList.contains("light")?"🌙":"☀️";
};