Anime Senpai - موقع أنمي ومانغا جاهز للنشر على GitHub Pages.
افتح index.html لمعاينة الموقع.